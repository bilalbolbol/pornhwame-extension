package eu.kanade.tachiyomi.extension.en.pornhwame

import eu.kanade.tachiyomi.source.model.*
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import okhttp3.*
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Locale

class PornhwaMe : ParsedHttpSource() {

    override val name = "Pornhwa.me"
    override val baseUrl = "https://pornhwa.me"
    override val lang = "en"
    override val supportsLatest = true

    override fun popularMangaRequest(page: Int) = GET("$baseUrl/hot-manga/page/$page", headers)
    override fun latestUpdatesRequest(page: Int) = GET("$baseUrl/page/$page", headers)
    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val genreFilter = filters.find { it is GenreFilter } as GenreFilter
        val genrePath = if (genreFilter.state != 0) "/genre/${genreFilter.toUriPart()}" else ""
        return GET("$baseUrl$genrePath/page/$page/?s=$query", headers)
    }

    override fun popularMangaSelector = "div.bs div.bsx"
    override fun latestUpdatesSelector = popularMangaSelector
    override fun searchMangaSelector = popularMangaSelector

    override fun popularMangaFromElement(element: Element): SManga {
        val manga = SManga.create()
        manga.title = element.selectFirst("a")!!.attr("title")
        manga.setUrlWithoutDomain(element.selectFirst("a")!!.attr("href"))
        manga.thumbnail_url = element.selectFirst("img")?.absUrl("src")
        return manga
    }

    override fun latestUpdatesFromElement(element: Element) = popularMangaFromElement(element)
    override fun searchMangaFromElement(element: Element) = popularMangaFromElement(element)

    override fun mangaDetailsParse(document: Document): SManga {
        val manga = SManga.create()
        val info = document.selectFirst("div.infox")!!

        manga.title = info.selectFirst("h1")?.text().orEmpty()
        manga.author = info.select("span:contains(Author)").text().removePrefix("Author:").trim()
        manga.artist = info.select("span:contains(Artist)").text().removePrefix("Artist:").trim()
        manga.status = parseStatus(info.select("span:contains(Status)").text())
        manga.genre = info.select("a[rel=tag]").joinToString { it.text() }
        manga.description = document.selectFirst("div.desc")?.text()
        manga.thumbnail_url = document.selectFirst("div.thumb img")?.absUrl("src")
        return manga
    }

    override fun chapterListSelector = "ul.clstyle li"
    override fun chapterFromElement(element: Element): SChapter {
        val chapter = SChapter.create()
        chapter.setUrlWithoutDomain(element.selectFirst("a")!!.attr("href"))
        chapter.name = element.selectFirst("a")!!.text()
        chapter.date_upload = parseDate(element.selectFirst(".date")?.text())
        return chapter
    }

    override fun pageListParse(document: Document): List<Page> {
        return document.select("div#readerarea img").mapIndexed { i, el ->
            Page(i, "", el.absUrl("src"))
        }
    }

    override fun imageUrlParse(document: Document) = ""

    private fun parseStatus(statusString: String): Int = when {
        statusString.contains("Ongoing", true) -> SManga.ONGOING
        statusString.contains("Completed", true) -> SManga.COMPLETED
        else -> SManga.UNKNOWN
    }

    private fun parseDate(date: String?): Long {
        return try {
            val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH)
            sdf.parse(date)?.time ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    // FILTERS
    override fun getFilterList(): FilterList {
        return FilterList(
            Filter.Header("Search will be filtered by genre"),
            GenreFilter()
        )
    }

    private class GenreFilter : Filter.Select<String>("Genre", genres.map { it.first }.toTypedArray()) {
        fun toUriPart(): String = genres[state].second
    }

    companion object {
        private val genres = listOf(
            Pair("All", ""),
            Pair("Mature", "mature"),
            Pair("Romance", "romance"),
            Pair("Drama", "drama"),
            Pair("Harem", "harem"),
            Pair("School Life", "school-life"),
            Pair("Supernatural", "supernatural"),
            Pair("Fantasy", "fantasy"),
            Pair("Comedy", "comedy"),
            Pair("Action", "action")
        )
    }
}
